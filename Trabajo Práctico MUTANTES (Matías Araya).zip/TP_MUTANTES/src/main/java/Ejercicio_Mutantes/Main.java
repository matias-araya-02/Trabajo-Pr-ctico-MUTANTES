/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicio_Mutantes;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author elmat
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        boolean salir = false; 
        
        do {            

            Scanner scanner = new Scanner(System.in); 
            System.out.println("");
            System.out.println(" --- TP MUTANTES --- ");
            System.out.println("");

            String dna [] = new String [6]; 

            Random random = new Random(); 
            String opciones = "ATCG";

            for (int i = 0; i < 6; i++) {
                StringBuilder secuencia = new StringBuilder();
                for (int j = 0; j < 6; j++) {
                    int index = random.nextInt(opciones.length());
                    secuencia.append(opciones.charAt(index));
                }
                dna[i] = secuencia.toString();
            }

            Mutante mutante = new Mutante(dna); 

            System.out.println("¿Es Mutante?: "+mutante.isMutant());

            System.out.println("");
            System.out.println("¿Desea cargar una nueva secuencia de ADN? ");
            System.out.println("1. SI");
            System.out.println("2. NO");
            System.out.print("--> ");
            int opcion = scanner.nextInt(); 
            
            switch (opcion) {
                case 1:
                    salir = false; 
                    break;
                case 2:
                    salir = true; 
                    System.out.println("Adios!");
                    break;
                default:
                    System.out.println("Opción Incorrecta!, saliendo...");
            }
            
        } while (!salir);
    }
    
}