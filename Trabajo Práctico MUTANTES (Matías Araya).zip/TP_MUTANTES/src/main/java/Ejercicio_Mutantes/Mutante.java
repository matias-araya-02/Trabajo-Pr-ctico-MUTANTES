/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio_Mutantes;

/**
 *
 * @author elmat
 */
public class Mutante {
    
    private String dna []; 

    public Mutante(String[] dna) {
        this.dna = dna;
    }

    public boolean isMutant() {
        char[][] matDNA = new char[6][6];
        for (int x = 0; x < matDNA.length; x++) {
            for (int y = 0; y < matDNA[x].length; y++) {
                matDNA[x][y] = dna[x].charAt(y);
            }
        }
        muestraMatriz(matDNA);
        return buscarElementosSeguidos(matDNA);
    }

    public static boolean buscarElementosSeguidos(char[][] matriz) {
        int filas = matriz.length;
        int columnas = matriz[0].length;

        // Número de elementos consecutivos requeridos
        int n = 4;

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (j + n <= columnas) {
                    // Verificar en la fila
                    if (sonIguales(matriz[i], j, j + n)) {
                        return true;
                    }
                }
                if (i + n <= filas) {
                    // Verificar en la columna
                    if (sonIgualesColumna(matriz, i, i + n, j)) {
                        return true;
                    }
                    if (j + n <= columnas) {
                        // Verificar en la diagonal principal
                        if (sonIgualesDiagonalPrincipal(matriz, i, j, n)) {
                            return true;
                        }
                    }
                    if (j - n + 1 >= 0) {
                        // Verificar en la diagonal invertida
                        if (sonIgualesDiagonalInvertida(matriz, i, j, n)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    // Función para verificar si n elementos en una fila son iguales
    public static boolean sonIguales(char[] fila, int inicio, int fin) {
        for (int i = inicio + 1; i < fin; i++) {
            if (fila[i] != fila[inicio]) {
                return false;
            }
        }
        return true;
    }

    // Función para verificar si n elementos en una columna son iguales
    public static boolean sonIgualesColumna(char[][] matriz, int inicioFila, int finFila, int columna) {
        for (int i = inicioFila + 1; i < finFila; i++) {
            if (matriz[i][columna] != matriz[inicioFila][columna]) {
                return false;
            }
        }
        return true;
    }

    // Función para verificar si n elementos en la diagonal principal son iguales
    public static boolean sonIgualesDiagonalPrincipal(char[][] matriz, int fila, int columna, int n) {
        for (int i = 1; i < n; i++) {
            if (matriz[fila + i][columna + i] != matriz[fila][columna]) {
                return false;
            }
        }
        return true;
    }

    // Función para verificar si n elementos en la diagonal invertida son iguales
    public static boolean sonIgualesDiagonalInvertida(char[][] matriz, int fila, int columna, int n) {
        for (int i = 1; i < n; i++) {
            if (matriz[fila + i][columna - i] != matriz[fila][columna]) {
                return false;
            }
        }
        return true;
    }

    public static void muestraMatriz(char[][] mat) {
        for (char[] ind : mat) {
            for (char valor : ind) {
                System.out.print(valor + "  ");
            }
            System.out.println("");
        }
    }
}